

# phpList REST API plugin

[![Build Status](https://travis-ci.com/phpList/phplist-plugin-restapi.svg?branch=master)](https://travis-ci.org/phpList/phplist-plugin-restapi)

## About this plugin

This repository contains the REST API Plugin v1 for phpList 3. It is contained
within the `plugins` folder, along with respective documentation and
plugin-specific tests.

